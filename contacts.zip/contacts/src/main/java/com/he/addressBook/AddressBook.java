package com.he.addressBook;

import java.util.ArrayList;
import java.util.List;

public class AddressBook {

	final List<Contact> contacts;

	public AddressBook() {
		contacts = new ArrayList<Contact>();
	}

	public void addContact(Contact contact) throws Exception {
		if (contacts.contains(contact)) {
			throw new Exception("Duplicate Contact");
		}
		for (Contact cont : contacts) {
			if (cont.getName().equalsIgnoreCase(contact.getName())) {
				throw new Exception("No such contact exists");
			}
		}
		contacts.add(contact);
	}

	public void deleteContact(String name) throws Exception {

		for (Contact contact : contacts) {
			if (contact.getName().equalsIgnoreCase(name)) {
				contacts.remove(contact);
			} else {
				throw new Exception("No such contact exists");
			}
		}

	}

	public void updateContact(String name, Contact contact) throws Exception {

		for (Contact cont : contacts) {
			if (contacts.contains(contact) && contact.getName().equalsIgnoreCase(cont.getName())) {
				throw new Exception("Duplicate Contact");
			}
			if (cont.getName().equalsIgnoreCase(name)) {
				int index = contacts.indexOf(cont);
				contacts.set(index, contact);
			} else {
				throw new Exception(name + " does not exists");
			}
		}
	}

	public List<Contact> searchByName(String name) {
		List<Contact> contactList = new ArrayList<>();
		if (!name.isEmpty()) {
			contacts.forEach(contact -> {
				if (contact.getName().toLowerCase().startsWith(name.toLowerCase())) {
					contactList.add(contact);
				}
			});
			return contactList;
		}
		return contacts;
	}

	public List<Contact> searchByOrganisation(String organisation) {
		List<Contact> contactList = new ArrayList<>();
		if (!organisation.isEmpty()) {
			contacts.forEach(contact -> {
				if (contact.getOrganisation().toLowerCase().startsWith(organisation.toLowerCase())) {
					contactList.add(contact);
				}
			});
			return contactList;
		}
		return contacts;
	}

}